import React from 'react'

const NullPage = () => {
  return (
    <h1>Null Page</h1>
  )
}

export default NullPage