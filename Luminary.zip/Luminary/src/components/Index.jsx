import React from 'react'
import SideBar from './SideBar'

const Index = () => {
  return (
    <>
        <SideBar />
        
    </>
  )
}

export default Index